
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-XXXXXXXXXX');
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { brand: { 500: '#6366f1', 600: '#4f46e5' } }
                }
            }
        }
        const translations = {
            tr: {
                nav_home:"Anasayfa",nav_about:"Hakkımda",nav_education:"Eğitim",nav_contact:"İletişim",hero_badge:"Yeni Projelere Açık",hero_intro:"Merhaba, ben",hero_desc_major:"İnternet ve Ağ Teknolojileri",hero_desc_1:"Sinop Üniversitesi'nde",hero_desc_2:"öğrencisiyim. Modern arayüzler ve güvenli ağ altyapıları tasarlayarak fikirleri hayata geçiriyorum.",hero_btn_contact:"İletişime Geç",hero_btn_projects:"Projelerimi Gör",hero_follow:"Takip Et:",footer_rights:"Tüm hakları saklıdır.",bot_header:"Yapay Zeka Asistanı",bot_status:"Çevrimiçi",bot_welcome:`Merhaba! Ben Yiğit'in sanal asistanıyım. Sana nasıl yardımcı olabilirim?<br><br>Şunları sorabilirsin:<ul class="list-disc list-inside mt-2 text-xs opacity-90"><li>Projelerin neler?</li><li>İletişim bilgileri?</li><li>Hangi dilleri biliyorsun?</li></ul>`,bot_input_place:"Bir mesaj yazın...",form_success:"Mesajınız başarıyla gönderildi! En kısa sürede dönüş yapacağım."
            },
            en: {
                nav_home:"Home",nav_about:"About",nav_education:"Education",nav_contact:"Contact",hero_badge:"Open to New Projects",hero_intro:"Hello, I'm",hero_desc_major:"Internet and Network Technologies",hero_desc_1:"Student at Sinop University,",hero_desc_2:". I bring ideas to life by designing modern interfaces and secure network infrastructures.",hero_btn_contact:"Contact Me",hero_btn_projects:"See My Projects",hero_follow:"Follow Me:",footer_rights:"All rights reserved.",bot_header:"AI Assistant",bot_status:"Online",bot_welcome:`Hello! I'm Yiğit's virtual assistant. How can I help you?<br><br>You can ask:<ul class="list-disc list-inside mt-2 text-xs opacity-90"><li>What are your projects?</li><li>Contact info?</li><li>Which languages do you know?</li></ul>`,bot_input_place:"Type a message...",form_success:"Your message has been sent successfully! I will get back to you as soon as possible."
            }
        };

        let currentLang = localStorage.getItem('lang') || 'tr';

        function toggleLanguage() {
            currentLang = currentLang === 'tr' ? 'en' : 'tr';
            localStorage.setItem('lang', currentLang);
            updateContent();
        }

        function updateContent() {
            const btnText = currentLang === 'tr' ? 'EN' : 'TR';
            document.querySelectorAll('#lang-btn-text, #lang-btn-text-mobile').forEach(el => el.textContent = btnText);
            const chatInput = document.getElementById('chat-input');
            if(chatInput) chatInput.placeholder = translations[currentLang]['bot_input_place'];
            const botWelcome = document.getElementById('bot-welcome-msg');
            if(botWelcome && !botWelcome.innerHTML) botWelcome.innerHTML = translations[currentLang]['bot_welcome'];

            document.querySelectorAll('[data-i18n]').forEach(element => {
                const key = element.getAttribute('data-i18n');
                if(translations[currentLang][key]) {
                    if(element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') element.placeholder = translations[currentLang][key];
                    else element.innerHTML = translations[currentLang][key];
                }
            });
        }

        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            const icon = document.getElementById('mobile-menu-icon');
            if (menu) {
                menu.classList.toggle('translate-x-full');
                menu.classList.toggle('shadow-2xl');
                if (menu.classList.contains('translate-x-full')) { icon.classList.remove('fa-times'); icon.classList.add('fa-bars'); } 
                else { icon.classList.remove('fa-bars'); icon.classList.add('fa-times'); }
            }
        }
        function toggleChat() {
            const chatWindow = document.getElementById('chat-window');
            chatWindow.classList.toggle('hidden');
            if (!chatWindow.classList.contains('hidden')) {
                document.getElementById('chat-input').focus();
                const botWelcome = document.getElementById('bot-welcome-msg');
                if(botWelcome.innerHTML === "") botWelcome.innerHTML = translations[currentLang]['bot_welcome'];
            }
        }
        function sendMessage(e) {
            e.preventDefault();
            const input = document.getElementById('chat-input');
            const message = input.value.trim();
            if (message) {
                addMessage(message, 'user');
                input.value = '';
                setTimeout(() => {
                    const response = getBotResponse(message.toLowerCase());
                    addMessage(response, 'bot');
                }, 600);
            }
        }
        function addMessage(text, sender) {
            const messagesContainer = document.getElementById('chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message-bubble ${sender === 'user' ? 'message-user' : 'message-bot'}`;
            messageDiv.innerHTML = text;
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        function getBotResponse(input) {
            if (currentLang === 'tr') {
                if (input.includes('merhaba') || input.includes('selam')) return "Merhaba! Hoş geldiniz. Size nasıl yardımcı olabilirim?";
                else if (input.includes('proje')) return "Projelerimi 'Projelerimi Gör' butonuna tıklayarak inceleyebilirsiniz. Genellikle React ve Node.js üzerine çalışıyorum.";
                else if (input.includes('iletişim') || input.includes('mail')) return "Bana <strong>yigitsen642@gmail.com</strong> adresinden ulaşabilirsiniz.";
                else if (input.includes('dil') || input.includes('teknoloji')) return "JavaScript, HTML ve CSS teknolojilerini aktif olarak kullanıyorum.";
                else return "Bunu tam anlayamadım ama iletişim sayfasından bana detaylı yazabilirsiniz.";
            } else {
                if (input.includes('hello') || input.includes('hi')) return "Hello! Welcome. How can I help you?";
                else if (input.includes('project')) return "You can check my projects by clicking the 'See My Projects' button.";
                else if (input.includes('contact') || input.includes('mail')) return "You can reach me at <strong>yigitsen642@gmail.com</strong>.";
                else if (input.includes('tech') || input.includes('skill')) return "I actively use JavaScript, HTML, and CSS.";
                else return "I didn't quite catch that, but feel free to write to me via the contact page.";
            }
        }
        const container = document.getElementById('hero-image-container');
        const content = document.getElementById('hero-image-content');
        if (container && content) {
            container.addEventListener('mousemove', (e) => {
                const rect = container.getBoundingClientRect();
                const x = e.clientX - rect.left, y = e.clientY - rect.top;
                const centerX = rect.width / 2, centerY = rect.height / 2;
                const rotateX = ((y - centerY) / centerY) * -10, rotateY = ((x - centerX) / centerX) * 10;
                content.classList.remove('animate-float');
                content.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.05, 1.05, 1.05)`;
            });
            container.addEventListener('mouseleave', () => { content.style.transform = ''; content.classList.add('animate-float'); });
        }
        const homeSection = document.getElementById('home');
        const animatedGrid = document.getElementById('animated-grid');
        if (homeSection && animatedGrid) {
            homeSection.addEventListener('mousemove', (e) => {
                const moveX = (e.clientX / window.innerWidth - 0.5) * -30;
                const moveY = (e.clientY / window.innerHeight - 0.5) * -30;
                animatedGrid.style.transform = `translate(${moveX}px, ${moveY}px)`;
            });
        }
        document.addEventListener('DOMContentLoaded', updateContent);
