         
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      // Kendi Ölçüm Kimliğinizi (Measurement ID) buraya girin:
      gtag('config', 'G-XXXXXXXXXX');

        tailwind.config = { theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { brand: { 500: '#6366f1', 600: '#4f46e5' } } } } }
        const translations = {
            tr: {
                nav_home:"Anasayfa",nav_about:"Hakkımda",nav_education:"Eğitim",nav_contact:"İletişim",hero_badge:"Yeni Projelere Açık",hero_intro:"Merhaba, ben",hero_desc_major:"İnternet ve Ağ Teknolojileri",hero_desc_1:"Sinop Üniversitesi'nde",hero_desc_2:"öğrencisiyim. Modern arayüzler ve güvenli ağ altyapıları tasarlayarak fikirleri hayata geçiriyorum.",hero_btn_contact:"İletişime Geç",hero_btn_projects:"Projelerimi Gör",hero_follow:"Takip Et:",footer_rights:"Tüm hakları saklıdır.",bot_header:"Yapay Zeka Asistanı",bot_status:"Çevrimiçi",bot_welcome:`Merhaba! Ben Yiğit'in sanal asistanıyım. Sana nasıl yardımcı olabilirim?<br><br>Şunları sorabilirsin:<ul class="list-disc list-inside mt-2 text-xs opacity-90"><li>Projelerin neler?</li><li>İletişim bilgileri?</li><li>Hangi dilleri biliyorsun?</li></ul>`,bot_input_place:"Bir mesaj yazın...",form_success:"Mesajınız başarıyla gönderildi! En kısa sürede dönüş yapacağım.",
                edu_title:"Eğitim Geçmişim",edu_uni_name:"Sinop Üniversitesi Ayancık Meslek Yüksek Okulu",edu_uni_desc:"Ağ mimarisi, sunucu yönetimi, siber güvenlik temelleri ve modern web teknolojileri üzerine uygulamalı eğitim alıyorum.",edu_hs_title:"Lise Eğitimi",edu_hs_desc:"Eşit ağırlık alanında eğitim aldım. Yazılım geliştirme merakım bu yıllarda başladı.",edu_ms_title:"Ortaokul Eğitimi",edu_ms_desc:"Temel akademik yetkinliklerimi kazandığım dönem.",edu_ps_title:"İlkokul Eğitimi",edu_ps_desc:"Eğitim hayatımın başlangıcı.",date_current:"2025 - Günümüz"
            },
            en: {
                nav_home:"Home",nav_about:"About",nav_education:"Education",nav_contact:"Contact",hero_badge:"Open to New Projects",hero_intro:"Hello, I'm",hero_desc_major:"Internet and Network Technologies",hero_desc_1:"Student at Sinop University,",hero_desc_2:". I bring ideas to life by designing modern interfaces and secure network infrastructures.",hero_btn_contact:"Contact Me",hero_btn_projects:"See My Projects",hero_follow:"Follow Me:",footer_rights:"All rights reserved.",bot_header:"AI Assistant",bot_status:"Online",bot_welcome:`Hello! I'm Yiğit's virtual assistant. How can I help you?<br><br>You can ask:<ul class="list-disc list-inside mt-2 text-xs opacity-90"><li>What are your projects?</li><li>Contact info?</li><li>Which languages do you know?</li></ul>`,bot_input_place:"Type a message...",form_success:"Your message has been sent successfully! I will get back to you as soon as possible.",
                edu_title:"Education History",edu_uni_name:"Sinop University Ayancik Vocational School",edu_uni_desc:"I am receiving applied training on network architecture, server management, cyber security fundamentals, and modern web technologies.",edu_hs_title:"High School Education",edu_hs_desc:"I studied in the equal weight field. My curiosity for software development started in these years.",edu_ms_title:"Middle School Education",edu_ms_desc:"The period when I gained my basic academic competencies.",edu_ps_title:"Primary School Education",edu_ps_desc:"The beginning of my educational life.",date_current:"2025 - Present"
            }
        };
        let currentLang = localStorage.getItem('lang') || 'tr';
        function toggleLanguage() {
            currentLang = currentLang === 'tr' ? 'en' : 'tr';
            localStorage.setItem('lang', currentLang);
            updateContent();
        }
        function updateContent() {
            const btnText = currentLang === 'tr' ? 'EN' : 'TR';
            document.querySelectorAll('#lang-btn-text, #lang-btn-text-mobile').forEach(el => el.textContent = btnText);
            const chatInput = document.getElementById('chat-input');
            if(chatInput) chatInput.placeholder = translations[currentLang]['bot_input_place'];
            const botWelcome = document.getElementById('bot-welcome-msg');
            if(botWelcome && !botWelcome.innerHTML) botWelcome.innerHTML = translations[currentLang]['bot_welcome'];

            document.querySelectorAll('[data-i18n]').forEach(element => {
                const key = element.getAttribute('data-i18n');
                if(translations[currentLang][key]) {
                    if(element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') element.placeholder = translations[currentLang][key];
                    else element.innerHTML = translations[currentLang][key];
                }
            });
        }

        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            const icon = document.getElementById('mobile-menu-icon');
            if (menu) {
                menu.classList.toggle('translate-x-full');
                menu.classList.toggle('shadow-2xl');
                if (menu.classList.contains('translate-x-full')) { icon.classList.remove('fa-times'); icon.classList.add('fa-bars'); } 
                else { icon.classList.remove('fa-bars'); icon.classList.add('fa-times'); }
            }
        }
        function toggleChat() {
            const chatWindow = document.getElementById('chat-window');
            chatWindow.classList.toggle('hidden');
            if (!chatWindow.classList.contains('hidden')) {
                document.getElementById('chat-input').focus();
                const botWelcome = document.getElementById('bot-welcome-msg');
                if(botWelcome.innerHTML === "") botWelcome.innerHTML = translations[currentLang]['bot_welcome'];
            }
        }
        function sendMessage(e) {
            e.preventDefault();
            const input = document.getElementById('chat-input');
            const message = input.value.trim();
            if (message) {
                addMessage(message, 'user');
                input.value = '';
                setTimeout(() => {
                    const response = getBotResponse(message.toLowerCase());
                    addMessage(response, 'bot');
                }, 600);
            }
        }
        function addMessage(text, sender) {
            const messagesContainer = document.getElementById('chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message-bubble ${sender === 'user' ? 'message-user' : 'message-bot'}`;
            messageDiv.innerHTML = text;
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        function getBotResponse(input) {
            if (currentLang === 'tr') {
                if (input.includes('merhaba') || input.includes('selam')) return "Merhaba! Hoş geldiniz. Size nasıl yardımcı olabilirim?";
                else if (input.includes('proje')) return "Projelerimi 'Projelerimi Gör' butonuna tıklayarak inceleyebilirsiniz. Genellikle React ve Node.js üzerine çalışıyorum.";
                else if (input.includes('iletişim') || input.includes('mail')) return "Bana <strong>yigitsen642@gmail.com</strong> adresinden ulaşabilirsiniz.";
                else if (input.includes('dil') || input.includes('teknoloji')) return "JavaScript, HTML ve CSS teknolojilerini aktif olarak kullanıyorum.";
                else return "Bunu tam anlayamadım ama iletişim sayfasından bana detaylı yazabilirsiniz.";
            } else {
                if (input.includes('hello') || input.includes('hi')) return "Hello! Welcome. How can I help you?";
                else if (input.includes('project')) return "You can check my projects by clicking the 'See My Projects' button.";
                else if (input.includes('contact') || input.includes('mail')) return "You can reach me at <strong>yigitsen642@gmail.com</strong>.";
                else if (input.includes('tech') || input.includes('skill')) return "I actively use JavaScript, HTML, and CSS.";
                else return "I didn't quite catch that, but feel free to write to me via the contact page.";
            }
        }
        document.addEventListener('DOMContentLoaded', updateContent);
        // Sayfa yüklendiğinde kayıtlı temayı kontrol et
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.documentElement.setAttribute('data-theme', savedTheme);
} else {
    // Kayıt yoksa sistem tercihine bak (Opsiyonel)
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    let targetTheme = 'light';

    if (currentTheme === 'dark') {
        targetTheme = 'light';
        document.documentElement.removeAttribute('data-theme'); // Dark özelliğini kaldır
    } else {
        targetTheme = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark'); // Dark özelliğini ekle
    }

    // Tercihi kaydet
    localStorage.setItem('theme', targetTheme);
}
        