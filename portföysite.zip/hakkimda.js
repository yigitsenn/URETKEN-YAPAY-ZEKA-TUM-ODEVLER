        

      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-XXXXXXXXXX');

           tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { brand: { 500: '#6366f1', 600: '#4f46e5' } }
                }
            }
        }
        const translations = {
            tr: {
                nav_home:"Anasayfa",nav_about:"Hakkımda",nav_education:"Eğitim",nav_contact:"İletişim",
                hero_desc_major:"İnternet ve Ağ Teknolojileri",
                about_title:"Hakkımda",about_role:"Full Stack Geliştirici Adayı",about_text_1:"Merhaba! Ben Sinop Üniversitesi'nde",about_text_2:"bölümünde okuyan tutkulu bir geliştiriciyim. Kod yazmak benim için sadece siyah ekran üzerine harfler dizmek değil, karmaşık problemleri zarif çözümlere dönüştürme sanatıdır.",about_text_3:"Lise yıllarımdan beri yazılım dünyasının içindeyim. Şu anda hem akademik eğitimimle ağ altyapılarını öğreniyor hem de modern web teknolojileri (Frontend & Backend) üzerine kendimi geliştiriyorum. Hedefim, kullanıcı deneyimini merkeze alan, hızlı ve güvenli dijital ürünler ortaya koymak.",service_web_title:"Web Geliştirme",service_web_desc:"Modern arayüzler ve güçlü arka plan servisleri ile tam donanımlı web uygulamaları geliştiriyorum.",service_net_title:"Ağ Teknolojileri",service_net_desc:"Okuduğum bölüm gereği ağ mimarisi, sunucu yönetimi ve siber güvenlik temellerine hakimim.",service_resp_title:"Responsive Tasarım",service_resp_desc:"Tüm cihazlarda (mobil, tablet, masaüstü) kusursuz çalışan duyarlı tasarımlar yapıyorum.",skills_title:"Yetkinliklerim",skills_tech:"Teknik",skills_soft:"Kişisel",skill_problem:"Problem Çözme",skill_learning:"Hızlı Öğrenme",skill_team:"Takım Çalışması",skill_analytic:"Analitik Düşünme",
                footer_rights:"Tüm hakları saklıdır.",bot_header:"Yapay Zeka Asistanı",bot_status:"Çevrimiçi",bot_welcome:`Merhaba! Ben Yiğit'in sanal asistanıyım. Sana nasıl yardımcı olabilirim?<br><br>Şunları sorabilirsin:<ul class="list-disc list-inside mt-2 text-xs opacity-90"><li>Projelerin neler?</li><li>İletişim bilgileri?</li><li>Hangi dilleri biliyorsun?</li></ul>`,bot_input_place:"Bir mesaj yazın...",form_success:"Mesajınız başarıyla gönderildi! En kısa sürede dönüş yapacağım."
            },
            en: {
                nav_home:"Home",nav_about:"About",nav_education:"Education",nav_contact:"Contact",
                hero_desc_major:"Internet and Network Technologies",
                about_title:"About Me",about_role:"Full Stack Developer Candidate",about_text_1:"Hello! I am a passionate developer studying",about_text_2:"at Sinop University. For me, writing code is not just arranging letters on a black screen, but the art of transforming complex problems into elegant solutions.",about_text_3:"I have been in the software world since my high school years. Currently, I am learning network infrastructures with my academic education and improving myself on modern web technologies (Frontend & Backend). My goal is to create fast and secure digital products centered on user experience.",service_web_title:"Web Development",service_web_desc:"I develop fully equipped web applications with modern interfaces and powerful background services.",service_net_title:"Network Technologies",service_net_desc:"Due to my department, I have a command of network architecture, server management, and cyber security fundamentals.",service_resp_title:"Responsive Design",service_resp_desc:"I create responsive designs that work flawlessly on all devices (mobile, tablet, desktop).",skills_title:"My Skills",skills_tech:"Technical",skills_soft:"Personal",skill_problem:"Problem Solving",skill_learning:"Fast Learning",skill_team:"Teamwork",skill_analytic:"Analytical Thinking",
                footer_rights:"All rights reserved.",bot_header:"AI Assistant",bot_status:"Online",bot_welcome:`Hello! I'm Yiğit's virtual assistant. How can I help you?<br><br>You can ask:<ul class="list-disc list-inside mt-2 text-xs opacity-90"><li>What are your projects?</li><li>Contact info?</li><li>Which languages do you know?</li></ul>`,bot_input_place:"Type a message...",form_success:"Your message has been sent successfully! I will get back to you as soon as possible."
            }
        };
        let currentLang = localStorage.getItem('lang') || 'tr';
        let isReading = false;
        function toggleLanguage() {
            if (isReading) stopSpeech();
            currentLang = currentLang === 'tr' ? 'en' : 'tr';
            localStorage.setItem('lang', currentLang);
            updateContent();
        }
        function updateContent() {
            const btnText = currentLang === 'tr' ? 'EN' : 'TR';
            document.querySelectorAll('#lang-btn-text, #lang-btn-text-mobile').forEach(el => el.textContent = btnText);
            const chatInput = document.getElementById('chat-input');
            if(chatInput) chatInput.placeholder = translations[currentLang]['bot_input_place'];
            const botWelcome = document.getElementById('bot-welcome-msg');
            if(botWelcome && !botWelcome.innerHTML) botWelcome.innerHTML = translations[currentLang]['bot_welcome'];

            document.querySelectorAll('[data-i18n]').forEach(element => {
                const key = element.getAttribute('data-i18n');
                if(translations[currentLang][key]) {
                    if(element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') element.placeholder = translations[currentLang][key];
                    else element.innerHTML = translations[currentLang][key];
                }
            });
        }
        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            const icon = document.getElementById('mobile-menu-icon');
            if (menu) {
                menu.classList.toggle('translate-x-full');
                menu.classList.toggle('shadow-2xl');
                if (menu.classList.contains('translate-x-full')) { icon.classList.remove('fa-times'); icon.classList.add('fa-bars'); } 
                else { icon.classList.remove('fa-bars'); icon.classList.add('fa-times'); }
            }
        }
        function toggleChat() {
            const chatWindow = document.getElementById('chat-window');
            chatWindow.classList.toggle('hidden');
            if (!chatWindow.classList.contains('hidden')) {
                document.getElementById('chat-input').focus();
                const botWelcome = document.getElementById('bot-welcome-msg');
                if(botWelcome.innerHTML === "") botWelcome.innerHTML = translations[currentLang]['bot_welcome'];
            }
        }
        function sendMessage(e) {
            e.preventDefault();
            const input = document.getElementById('chat-input');
            const message = input.value.trim();
            if (message) {
                addMessage(message, 'user');
                input.value = '';
                setTimeout(() => {
                    const response = getBotResponse(message.toLowerCase());
                    addMessage(response, 'bot');
                }, 600);
            }
        }
        function addMessage(text, sender) {
            const messagesContainer = document.getElementById('chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message-bubble ${sender === 'user' ? 'message-user' : 'message-bot'}`;
            messageDiv.innerHTML = text;
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        function getBotResponse(input) {
            if (currentLang === 'tr') {
                if (input.includes('merhaba') || input.includes('selam')) return "Merhaba! Hoş geldiniz. Size nasıl yardımcı olabilirim?";
                else if (input.includes('proje')) return "Projelerimi 'Projelerimi Gör' butonuna tıklayarak inceleyebilirsiniz. Genellikle React ve Node.js üzerine çalışıyorum.";
                else if (input.includes('iletişim') || input.includes('mail')) return "Bana <strong>yigitsen642@gmail.com</strong> adresinden ulaşabilirsiniz.";
                else if (input.includes('dil') || input.includes('teknoloji')) return "JavaScript, HTML ve CSS teknolojilerini aktif olarak kullanıyorum.";
                else return "Bunu tam anlayamadım ama iletişim sayfasından bana detaylı yazabilirsiniz.";
            } else {
                if (input.includes('hello') || input.includes('hi')) return "Hello! Welcome. How can I help you?";
                else if (input.includes('project')) return "You can check my projects by clicking the 'See My Projects' button.";
                else if (input.includes('contact') || input.includes('mail')) return "You can reach me at <strong>yigitsen642@gmail.com</strong>.";
                else if (input.includes('tech') || input.includes('skill')) return "I actively use JavaScript, HTML, and CSS.";
                else return "I didn't quite catch that, but feel free to write to me via the contact page.";
            }
        }
        function toggleSpeech() {
            if (isReading) stopSpeech();
            else startSpeech();
        }
        function startSpeech() {
            const activeSection = document.getElementById('about'); // ID'yi direkt seç
            if (!activeSection) return;
            if (!window.speechSynthesis) { alert("Tarayıcınız sesli okuma özelliğini desteklemiyor."); return; }
            const textToRead = activeSection.innerText;
            const utterance = new SpeechSynthesisUtterance(textToRead);
            utterance.lang = currentLang === 'tr' ? 'tr-TR' : 'en-US';
            utterance.rate = 0.9;
            utterance.onend = () => { isReading = false; updateSpeechIcons(false); };
            utterance.onerror = () => { isReading = false; updateSpeechIcons(false); };
            window.speechSynthesis.speak(utterance);
            isReading = true;
            updateSpeechIcons(true);
        }
        function stopSpeech() {
            if (window.speechSynthesis) window.speechSynthesis.cancel();
            isReading = false;
            updateSpeechIcons(false);
        }
        function updateSpeechIcons(isActive) {
            const icons = [document.getElementById('speech-icon-desktop'), document.getElementById('speech-icon-mobile')];
            icons.forEach(icon => {
                if(icon) {
                    if (isActive) { icon.classList.remove('fa-volume-up'); icon.classList.add('fa-stop', 'text-red-400', 'animate-pulse'); } 
                    else { icon.classList.add('fa-volume-up'); icon.classList.remove('fa-stop', 'text-red-400', 'animate-pulse'); }
                }
            });
        }
        document.addEventListener('DOMContentLoaded', updateContent);
        // Sayfa yüklendiğinde kayıtlı temayı kontrol et
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.documentElement.setAttribute('data-theme', savedTheme);
} else {
    // Kayıt yoksa sistem tercihine bak (Opsiyonel)
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    let targetTheme = 'light';

    if (currentTheme === 'dark') {
        targetTheme = 'light';
        document.documentElement.removeAttribute('data-theme'); // Dark özelliğini kaldır
    } else {
        targetTheme = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark'); // Dark özelliğini ekle
    }

    // Tercihi kaydet
    localStorage.setItem('theme', targetTheme);
}
