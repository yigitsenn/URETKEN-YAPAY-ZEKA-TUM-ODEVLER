/**
 * Main game React component.
 * Manages game loop, input handling, and UI overlays (start screen, game over, HUD).
 */

import { useRef, useState, useEffect, useCallback } from "react";
import type { GameState, Vector2, LeaderboardEntry } from "../game/types";
import { createGameState, updateGame, splitPlayer, ejectMass, getLeaderboard } from "../game/engine";
import { render, screenToWorld, resetCamera } from "../game/renderer";
import { getCenterOfMass, getTotalMass } from "../game/utils";
import { SKINS, CELL_COLORS } from "../game/constants";

type GameScreen = "menu" | "playing" | "gameover";

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [screen, setScreen] = useState<GameScreen>("menu");
  const [playerName, setPlayerName] = useState("");
  const [selectedSkin, setSelectedSkin] = useState(0);
  const [finalScore, setFinalScore] = useState(0);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  // Game refs (not state, to avoid re-renders during gameplay)
  const stateRef = useRef<GameState | null>(null);
  const playerIdRef = useRef<string>("");
  const targetRef = useRef<Vector2 | null>(null);
  const animFrameRef = useRef<number>(0);

  const startGame = useCallback(() => {
    const name = playerName.trim() || "Player";
    const { state, playerId } = createGameState(name);
    stateRef.current = state;
    playerIdRef.current = playerId;

    // Apply selected skin
    const player = state.players.get(playerId);
    if (player) player.skin = selectedSkin;

    resetCamera();
    setScreen("playing");
  }, [playerName, selectedSkin]);

  // Game loop
  useEffect(() => {
    if (screen !== "playing") return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let running = true;
    let leaderboardTimer = 0;

    function resize() {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    function loop() {
      if (!running || !stateRef.current || !canvas || !ctx) return;

      const state = stateRef.current;
      const playerId = playerIdRef.current;
      const player = state.players.get(playerId);

      // Check game over
      if (!player || !player.alive) {
        setFinalScore(player?.score || 0);
        setScreen("gameover");
        return;
      }

      // Update game logic
      updateGame(state, playerId, targetRef.current);

      // Render
      render(ctx, canvas, state, playerId);

      // Draw HUD overlay (leaderboard)
      leaderboardTimer++;
      if (leaderboardTimer % 30 === 0) {
        setLeaderboard(getLeaderboard(state));
      }

      animFrameRef.current = requestAnimationFrame(loop);
    }

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener("resize", resize);
    };
  }, [screen]);

  // Input handling
  useEffect(() => {
    if (screen !== "playing") return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Mouse/touch → world position
    function handlePointerMove(e: PointerEvent) {
      targetRef.current = screenToWorld(e.clientX, e.clientY, canvas!.width, canvas!.height);
    }

    function handleTouchMove(e: TouchEvent) {
      e.preventDefault();
      const touch = e.touches[0];
      if (touch) {
        targetRef.current = screenToWorld(touch.clientX, touch.clientY, canvas!.width, canvas!.height);
      }
    }

    // Split on space or double tap
    function handleKeyDown(e: KeyboardEvent) {
      const state = stateRef.current;
      const player = state?.players.get(playerIdRef.current);
      if (!player || !targetRef.current) return;

      if (e.code === "Space") {
        e.preventDefault();
        splitPlayer(player, targetRef.current);
      }
      if (e.code === "KeyW") {
        e.preventDefault();
        ejectMass(state!, player, targetRef.current);
      }
    }

    // Double-tap to split on mobile
    let lastTap = 0;
    function handleTouchStart(e: TouchEvent) {
      const now = Date.now();
      if (now - lastTap < 300) {
        const state = stateRef.current;
        const player = state?.players.get(playerIdRef.current);
        if (player && targetRef.current) {
          splitPlayer(player, targetRef.current);
        }
      }
      lastTap = now;

      const touch = e.touches[0];
      if (touch) {
        targetRef.current = screenToWorld(touch.clientX, touch.clientY, canvas!.width, canvas!.height);
      }
    }

    canvas.addEventListener("pointermove", handlePointerMove);
    canvas.addEventListener("touchmove", handleTouchMove, { passive: false });
    canvas.addEventListener("touchstart", handleTouchStart);
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      canvas.removeEventListener("pointermove", handlePointerMove);
      canvas.removeEventListener("touchmove", handleTouchMove);
      canvas.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [screen]);

  // --- MENU SCREEN ---
  if (screen === "menu") {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        {/* Animated background dots */}
        <div className="absolute inset-0 overflow-hidden">
          {Array.from({ length: 30 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full opacity-20"
              style={{
                width: 6 + Math.random() * 20,
                height: 6 + Math.random() * 20,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                backgroundColor: CELL_COLORS[i % CELL_COLORS.length],
                animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 3}s`,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 flex flex-col items-center gap-6 px-6">
          {/* Title */}
          <h1 className="text-6xl font-black tracking-tighter sm:text-8xl"
            style={{
              background: "linear-gradient(135deg, #FF6B6B, #4ECDC4, #45B7D1, #FFD93D)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            CellStorm
          </h1>
          <p className="text-muted-foreground text-lg">Consume. Grow. Dominate.</p>

          {/* Name input */}
          <input
            type="text"
            placeholder="Enter your name..."
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            maxLength={16}
            onKeyDown={(e) => e.key === "Enter" && startGame()}
            className="w-64 rounded-xl border border-border bg-card px-4 py-3 text-center text-lg text-foreground outline-none focus:ring-2 focus:ring-primary"
          />

          {/* Skin selection */}
          <div className="flex flex-col items-center gap-2">
            <span className="text-sm text-muted-foreground">Choose skin</span>
            <div className="flex gap-2">
              {SKINS.map((skin, idx) => (
                <button
                  key={skin}
                  onClick={() => setSelectedSkin(idx)}
                  className={`h-10 w-10 rounded-full border-2 transition-all ${
                    selectedSkin === idx
                      ? "scale-110 border-primary shadow-lg"
                      : "border-border opacity-60 hover:opacity-100"
                  }`}
                  style={{ backgroundColor: CELL_COLORS[idx] }}
                  title={skin}
                />
              ))}
            </div>
          </div>

          {/* Play button */}
          <button
            onClick={startGame}
            className="mt-2 rounded-2xl px-12 py-4 text-xl font-bold text-foreground transition-all hover:scale-105 active:scale-95"
            style={{
              background: "linear-gradient(135deg, #FF6B6B, #4ECDC4)",
              color: "#fff",
            }}
          >
            ▶ Play
          </button>

          {/* Controls hint */}
          <div className="mt-4 text-center text-xs text-muted-foreground">
            <p>Move: Mouse / Touch</p>
            <p>Split: Space / Double-tap</p>
            <p>Eject mass: W</p>
          </div>
        </div>

        <style>{`
          @keyframes float {
            0%, 100% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-20px) scale(1.1); }
          }
        `}</style>
      </div>
    );
  }

  // --- GAME OVER SCREEN ---
  if (screen === "gameover") {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-6 px-6 text-center">
          <h2 className="text-5xl font-black text-foreground">Game Over</h2>
          <div className="rounded-2xl border border-border bg-card px-8 py-6">
            <p className="text-muted-foreground text-sm">Your score</p>
            <p className="text-5xl font-black" style={{ color: "#FFD93D" }}>
              {finalScore}
            </p>
          </div>

          {/* Final leaderboard */}
          <div className="w-64 rounded-xl border border-border bg-card p-4">
            <h3 className="mb-2 text-sm font-bold text-muted-foreground">Leaderboard</h3>
            {leaderboard.slice(0, 5).map((entry, i) => (
              <div key={i} className="flex items-center justify-between py-1">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ backgroundColor: entry.color }} />
                  <span className="text-sm text-foreground">{entry.name}</span>
                </div>
                <span className="text-xs text-muted-foreground">{entry.score}</span>
              </div>
            ))}
          </div>

          <button
            onClick={startGame}
            className="rounded-2xl px-10 py-3 text-lg font-bold transition-all hover:scale-105 active:scale-95"
            style={{
              background: "linear-gradient(135deg, #FF6B6B, #4ECDC4)",
              color: "#fff",
            }}
          >
            Play Again
          </button>
        </div>
      </div>
    );
  }

  // --- PLAYING SCREEN ---
  return (
    <div className="fixed inset-0">
      <canvas ref={canvasRef} className="block h-full w-full" style={{ touchAction: "none" }} />

      {/* HUD Leaderboard */}
      <div className="absolute right-3 top-3 w-44 rounded-xl border border-border/50 bg-card/80 p-3 backdrop-blur-sm">
        <h3 className="mb-1 text-xs font-bold text-muted-foreground uppercase tracking-wider">Leaderboard</h3>
        {leaderboard.map((entry, i) => (
          <div key={i} className="flex items-center justify-between py-0.5">
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground w-4">{i + 1}</span>
              <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-xs text-foreground truncate max-w-20">{entry.name}</span>
            </div>
            <span className="text-xs text-muted-foreground">{entry.score}</span>
          </div>
        ))}
      </div>

      {/* Mobile split button */}
      <button
        onTouchStart={(e) => {
          e.preventDefault();
          const state = stateRef.current;
          const player = state?.players.get(playerIdRef.current);
          if (player && targetRef.current) splitPlayer(player, targetRef.current);
        }}
        className="absolute bottom-6 right-6 flex h-16 w-16 items-center justify-center rounded-full border border-border/50 bg-card/60 text-2xl text-foreground backdrop-blur-sm active:scale-90 sm:hidden"
      >
        ✂
      </button>

      {/* Mobile eject button */}
      <button
        onTouchStart={(e) => {
          e.preventDefault();
          const state = stateRef.current;
          const player = state?.players.get(playerIdRef.current);
          if (player && state && targetRef.current) ejectMass(state, player, targetRef.current);
        }}
        className="absolute bottom-6 left-6 flex h-16 w-16 items-center justify-center rounded-full border border-border/50 bg-card/60 text-2xl text-foreground backdrop-blur-sm active:scale-90 sm:hidden"
      >
        💧
      </button>

      {/* Score display */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-border/50 bg-card/60 px-4 py-1 backdrop-blur-sm">
        <span className="text-sm font-bold text-foreground">
          Score: {stateRef.current?.players.get(playerIdRef.current)?.score || 0}
        </span>
      </div>
    </div>
  );
}
