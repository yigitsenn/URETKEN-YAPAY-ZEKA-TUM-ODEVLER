/**
 * Game configuration constants.
 * Tweak these to change gameplay feel.
 */

// Map dimensions
export const MAP_WIDTH = 6000;
export const MAP_HEIGHT = 6000;

// Grid lines spacing for background
export const GRID_SIZE = 50;

// Player settings
export const INITIAL_MASS = 20;
export const INITIAL_RADIUS = 20;
export const BASE_SPEED = 4;
export const MIN_SPEED = 1.2;
export const SPEED_DECAY = 0.012; // how much speed decreases per mass unit

// Food
export const FOOD_COUNT = 800;
export const FOOD_RADIUS = 5;
export const FOOD_MASS = 1;

// Splitting
export const MIN_SPLIT_MASS = 40;
export const SPLIT_SPEED = 18;
export const MERGE_DELAY = 300; // frames before cells can re-merge (~5s at 60fps)
export const MAX_CELLS_PER_PLAYER = 16;

// Ejecting mass
export const EJECT_MASS_COST = 16;
export const EJECT_SPEED = 20;
export const EJECT_RADIUS = 6;

// Bots
export const BOT_COUNT = 15;
export const BOT_NAMES = [
  "Blob", "Chomper", "Nom", "Globby", "Squishy",
  "Muncher", "Nibbler", "Goopy", "Jellix", "Oozy",
  "Slurp", "Bubbles", "Morph", "Gulper", "Wiggly",
  "Snacker", "Blobzilla", "Orbius", "Sphero", "Dotty",
];

// Power-ups
export const POWERUP_SPAWN_INTERVAL = 600; // frames between spawns
export const POWERUP_LIFETIME = 600;
export const SPEED_BOOST_MULT = 2;
export const SPEED_BOOST_DURATION = 180; // frames

// Colors palette for cells
export const CELL_COLORS = [
  "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4",
  "#FFEAA7", "#DDA0DD", "#FF8A5C", "#A8E6CF",
  "#FFD93D", "#6BCB77", "#4D96FF", "#FF6B9D",
  "#C084FC", "#F97316", "#06B6D4", "#EC4899",
];

// Skins — drawn as patterns on cells
export const SKINS = [
  "none",        // default solid color
  "stripes",     // horizontal stripes
  "dots",        // polka dots
  "star",        // star overlay
  "gradient",    // radial gradient
];

// Camera
export const CAMERA_LERP = 0.08;
export const ZOOM_LERP = 0.04;
export const BASE_ZOOM = 1;
export const MIN_ZOOM = 0.25;
