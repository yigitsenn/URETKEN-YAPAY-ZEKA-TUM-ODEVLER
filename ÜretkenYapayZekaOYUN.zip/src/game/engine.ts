/**
 * Core game engine — handles all game logic:
 * movement, collision, consumption, splitting, AI, power-ups.
 */

import type { GameState, Player, Cell, Food, EjectedMass, PowerUp, Vector2, LeaderboardEntry } from "./types";
import {
  MAP_WIDTH, MAP_HEIGHT, INITIAL_MASS, BASE_SPEED, MIN_SPEED,
  SPEED_DECAY, FOOD_COUNT, FOOD_RADIUS, FOOD_MASS, MIN_SPLIT_MASS,
  SPLIT_SPEED, MERGE_DELAY, MAX_CELLS_PER_PLAYER, EJECT_MASS_COST,
  EJECT_SPEED, EJECT_RADIUS, BOT_COUNT, BOT_NAMES, CELL_COLORS,
  POWERUP_SPAWN_INTERVAL, POWERUP_LIFETIME, SPEED_BOOST_MULT,
  SPEED_BOOST_DURATION,
} from "./constants";
import {
  distance, massToRadius, clamp, lerp, getTotalMass,
  getCenterOfMass, randomPosition, randomPick, normalize,
} from "./utils";

let nextId = 1;
function genId() { return nextId++; }

/** Create a fresh game state populated with food and bots */
export function createGameState(playerName: string): { state: GameState; playerId: string } {
  const state: GameState = {
    players: new Map(),
    food: [],
    ejectedMass: [],
    powerUps: [],
  };

  // Spawn food
  for (let i = 0; i < FOOD_COUNT; i++) {
    state.food.push(createFood());
  }

  // Create human player
  const playerId = "player_" + genId();
  const playerColor = randomPick(CELL_COLORS);
  state.players.set(playerId, createPlayer(playerId, playerName, playerColor, false));

  // Spawn bots
  for (let i = 0; i < BOT_COUNT; i++) {
    const botId = "bot_" + genId();
    const botColor = randomPick(CELL_COLORS);
    const botName = BOT_NAMES[i % BOT_NAMES.length];
    state.players.set(botId, createPlayer(botId, botName, botColor, true));
  }

  return { state, playerId };
}

function createPlayer(id: string, name: string, color: string, isBot: boolean): Player {
  const pos = randomPosition(MAP_WIDTH, MAP_HEIGHT);
  return {
    id, name, color, isBot, score: 0, alive: true,
    skin: isBot ? Math.floor(Math.random() * 5) : 0,
    cells: [{
      id: genId(), x: pos.x, y: pos.y,
      radius: massToRadius(INITIAL_MASS), mass: INITIAL_MASS,
      vx: 0, vy: 0, color, mergeTimer: 0,
    }],
  };
}

function createFood(): Food {
  const pos = randomPosition(MAP_WIDTH, MAP_HEIGHT, 20);
  return {
    id: genId(), x: pos.x, y: pos.y,
    radius: FOOD_RADIUS,
    color: randomPick(CELL_COLORS),
  };
}

/** Calculate speed based on mass — bigger = slower */
function getSpeed(mass: number): number {
  return Math.max(MIN_SPEED, BASE_SPEED - SPEED_DECAY * mass);
}

/**
 * Main update tick. Call once per frame.
 * @param target - mouse/touch position in world coords for human player
 */
export function updateGame(
  state: GameState,
  playerId: string,
  target: Vector2 | null,
  dt: number = 1
): void {
  // Update each player
  for (const [id, player] of state.players) {
    if (!player.alive) continue;

    if (id === playerId && target) {
      // Move human cells toward target
      movePlayerCells(player, target, dt);
    } else if (player.isBot) {
      // AI behavior
      updateBot(state, player, dt);
    }

    // Merge timer countdown & merging
    handleCellMerging(player);

    // Clamp to map bounds
    for (const cell of player.cells) {
      cell.x = clamp(cell.x, cell.radius, MAP_WIDTH - cell.radius);
      cell.y = clamp(cell.y, cell.radius, MAP_HEIGHT - cell.radius);
    }

    // Update score
    player.score = Math.floor(getTotalMass(player.cells));
  }

  // Food consumption
  checkFoodConsumption(state);

  // Ejected mass consumption
  checkEjectedMassConsumption(state);

  // Player-vs-player consumption
  checkPlayerConsumption(state);

  // Power-up spawning
  handlePowerUps(state);

  // Replenish food
  while (state.food.length < FOOD_COUNT) {
    state.food.push(createFood());
  }

  // Respawn dead bots
  for (const [id, player] of state.players) {
    if (!player.alive && player.isBot) {
      const pos = randomPosition(MAP_WIDTH, MAP_HEIGHT);
      player.alive = true;
      player.cells = [{
        id: genId(), x: pos.x, y: pos.y,
        radius: massToRadius(INITIAL_MASS), mass: INITIAL_MASS,
        vx: 0, vy: 0, color: player.color, mergeTimer: 0,
      }];
    }
  }

  // Update ejected mass
  for (let i = state.ejectedMass.length - 1; i >= 0; i--) {
    const em = state.ejectedMass[i];
    em.x += em.vx;
    em.y += em.vy;
    em.vx *= 0.9;
    em.vy *= 0.9;
    em.lifetime--;
    if (em.lifetime <= 0 || em.x < 0 || em.x > MAP_WIDTH || em.y < 0 || em.y > MAP_HEIGHT) {
      state.ejectedMass.splice(i, 1);
    }
  }
}

/** Move all cells of a player toward a world-space target */
function movePlayerCells(player: Player, target: Vector2, dt: number): void {
  for (const cell of player.cells) {
    const dx = target.x - cell.x;
    const dy = target.y - cell.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 5) continue; // dead zone to prevent jitter

    const speed = getSpeed(cell.mass) * dt;
    const nx = dx / dist;
    const ny = dy / dist;

    // Apply velocity (includes split momentum)
    cell.x += nx * speed + cell.vx;
    cell.y += ny * speed + cell.vy;

    // Decay split velocity
    cell.vx *= 0.9;
    cell.vy *= 0.9;
  }
}

/** Simple bot AI: chase food, flee from bigger cells, attack smaller ones */
function updateBot(state: GameState, bot: Player, dt: number): void {
  const center = getCenterOfMass(bot.cells);
  const totalMass = getTotalMass(bot.cells);

  let targetX = center.x;
  let targetY = center.y;
  let bestScore = -Infinity;

  // Look for food nearby
  for (const food of state.food) {
    const dist = distance(center, food);
    if (dist < 400) {
      const score = 100 / (dist + 1);
      if (score > bestScore) {
        bestScore = score;
        targetX = food.x;
        targetY = food.y;
      }
    }
  }

  // Look for smaller players to chase
  for (const [, other] of state.players) {
    if (other.id === bot.id || !other.alive) continue;
    const otherCenter = getCenterOfMass(other.cells);
    const otherMass = getTotalMass(other.cells);
    const dist = distance(center, otherCenter);

    if (dist < 500 && otherMass < totalMass * 0.8) {
      // Chase smaller player
      const score = (totalMass - otherMass) * 2 / (dist + 1);
      if (score > bestScore) {
        bestScore = score;
        targetX = otherCenter.x;
        targetY = otherCenter.y;
      }
    } else if (dist < 400 && otherMass > totalMass * 1.2) {
      // Flee from bigger player
      const fleeX = center.x + (center.x - otherCenter.x);
      const fleeY = center.y + (center.y - otherCenter.y);
      const score = otherMass * 3 / (dist + 1);
      if (score > bestScore) {
        bestScore = score;
        targetX = fleeX;
        targetY = fleeY;
      }
    }
  }

  // Occasional random wandering
  if (bestScore === -Infinity || Math.random() < 0.01) {
    targetX = center.x + (Math.random() - 0.5) * 600;
    targetY = center.y + (Math.random() - 0.5) * 600;
  }

  // Bot splitting when chasing smaller prey and big enough
  if (totalMass > MIN_SPLIT_MASS * 2 && bot.cells.length < 4 && Math.random() < 0.003) {
    splitPlayer(bot, { x: targetX, y: targetY });
  }

  movePlayerCells(bot, { x: targetX, y: targetY }, dt);
}

/** Handle cell merging after merge timer expires */
function handleCellMerging(player: Player): void {
  for (const cell of player.cells) {
    if (cell.mergeTimer > 0) cell.mergeTimer--;
  }

  // Try to merge overlapping cells
  for (let i = 0; i < player.cells.length; i++) {
    for (let j = i + 1; j < player.cells.length; j++) {
      const a = player.cells[i];
      const b = player.cells[j];
      if (a.mergeTimer > 0 || b.mergeTimer > 0) continue;

      const dist = distance(a, b);
      if (dist < a.radius + b.radius - Math.min(a.radius, b.radius) * 0.5) {
        // Merge b into a
        a.mass += b.mass;
        a.radius = massToRadius(a.mass);
        a.x = (a.x * a.mass + b.x * b.mass) / (a.mass + b.mass);
        a.y = (a.y * a.mass + b.y * b.mass) / (a.mass + b.mass);
        player.cells.splice(j, 1);
        j--;
      }
    }
  }

  // Push apart own cells that haven't merged yet
  for (let i = 0; i < player.cells.length; i++) {
    for (let j = i + 1; j < player.cells.length; j++) {
      const a = player.cells[i];
      const b = player.cells[j];
      const dist = distance(a, b);
      const overlap = a.radius + b.radius - dist;
      if (overlap > 0 && (a.mergeTimer > 0 || b.mergeTimer > 0)) {
        const nx = (b.x - a.x) / (dist || 1);
        const ny = (b.y - a.y) / (dist || 1);
        const push = overlap * 0.3;
        a.x -= nx * push;
        a.y -= ny * push;
        b.x += nx * push;
        b.y += ny * push;
      }
    }
  }
}

/** Check food consumption by all players */
function checkFoodConsumption(state: GameState): void {
  for (const [, player] of state.players) {
    if (!player.alive) continue;
    for (const cell of player.cells) {
      for (let i = state.food.length - 1; i >= 0; i--) {
        const food = state.food[i];
        if (distance(cell, food) < cell.radius) {
          cell.mass += FOOD_MASS;
          cell.radius = massToRadius(cell.mass);
          state.food.splice(i, 1);
        }
      }
    }
  }
}

/** Check ejected mass consumption */
function checkEjectedMassConsumption(state: GameState): void {
  for (const [, player] of state.players) {
    if (!player.alive) continue;
    for (const cell of player.cells) {
      for (let i = state.ejectedMass.length - 1; i >= 0; i--) {
        const em = state.ejectedMass[i];
        if (distance(cell, em) < cell.radius) {
          cell.mass += em.radius;
          cell.radius = massToRadius(cell.mass);
          state.ejectedMass.splice(i, 1);
        }
      }
    }
  }
}

/** Check player vs player consumption */
function checkPlayerConsumption(state: GameState): void {
  const players = Array.from(state.players.values()).filter(p => p.alive);

  for (let pi = 0; pi < players.length; pi++) {
    for (let pj = pi + 1; pj < players.length; pj++) {
      const pA = players[pi];
      const pB = players[pj];

      for (const cellA of pA.cells) {
        for (let ci = pB.cells.length - 1; ci >= 0; ci--) {
          const cellB = pB.cells[ci];
          const dist = distance(cellA, cellB);

          // A eats B if A is significantly larger and overlaps enough
          if (cellA.mass > cellB.mass * 1.15 && dist < cellA.radius - cellB.radius * 0.4) {
            cellA.mass += cellB.mass;
            cellA.radius = massToRadius(cellA.mass);
            pB.cells.splice(ci, 1);
            if (pB.cells.length === 0) pB.alive = false;
          }
          // B eats A
          else if (cellB.mass > cellA.mass * 1.15 && dist < cellB.radius - cellA.radius * 0.4) {
            cellB.mass += cellA.mass;
            cellB.radius = massToRadius(cellB.mass);
            // Remove cellA from pA
            const idx = pA.cells.indexOf(cellA);
            if (idx !== -1) pA.cells.splice(idx, 1);
            if (pA.cells.length === 0) pA.alive = false;
            break;
          }
        }
        if (!pA.alive) break;
      }
    }
  }
}

/** Split a player's cells toward a target direction */
export function splitPlayer(player: Player, target: Vector2): void {
  const newCells: Cell[] = [];

  for (const cell of player.cells) {
    if (player.cells.length + newCells.length >= MAX_CELLS_PER_PLAYER) break;
    if (cell.mass < MIN_SPLIT_MASS) continue;

    const halfMass = cell.mass / 2;
    cell.mass = halfMass;
    cell.radius = massToRadius(cell.mass);

    const dir = normalize({ x: target.x - cell.x, y: target.y - cell.y });

    newCells.push({
      id: genId(),
      x: cell.x + dir.x * cell.radius,
      y: cell.y + dir.y * cell.radius,
      radius: massToRadius(halfMass),
      mass: halfMass,
      vx: dir.x * SPLIT_SPEED,
      vy: dir.y * SPLIT_SPEED,
      color: cell.color,
      mergeTimer: MERGE_DELAY,
    });

    cell.mergeTimer = MERGE_DELAY;
  }

  player.cells.push(...newCells);
}

/** Eject mass from player cells toward target */
export function ejectMass(state: GameState, player: Player, target: Vector2): void {
  for (const cell of player.cells) {
    if (cell.mass < EJECT_MASS_COST + INITIAL_MASS) continue;

    cell.mass -= EJECT_MASS_COST;
    cell.radius = massToRadius(cell.mass);

    const dir = normalize({ x: target.x - cell.x, y: target.y - cell.y });

    state.ejectedMass.push({
      id: genId(),
      x: cell.x + dir.x * (cell.radius + EJECT_RADIUS),
      y: cell.y + dir.y * (cell.radius + EJECT_RADIUS),
      radius: EJECT_RADIUS,
      vx: dir.x * EJECT_SPEED,
      vy: dir.y * EJECT_SPEED,
      color: cell.color,
      lifetime: 300,
    });
  }
}

/** Power-up spawning and collection */
let powerUpTimer = 0;
function handlePowerUps(state: GameState): void {
  powerUpTimer++;
  if (powerUpTimer >= POWERUP_SPAWN_INTERVAL && state.powerUps.length < 5) {
    const pos = randomPosition(MAP_WIDTH, MAP_HEIGHT);
    const types: Array<"speed" | "shield" | "mass"> = ["speed", "shield", "mass"];
    state.powerUps.push({
      id: genId(),
      x: pos.x, y: pos.y,
      type: randomPick(types),
      radius: 15,
      lifetime: POWERUP_LIFETIME,
    });
    powerUpTimer = 0;
  }

  // Check collection & decay
  for (let i = state.powerUps.length - 1; i >= 0; i--) {
    const pu = state.powerUps[i];
    pu.lifetime--;
    if (pu.lifetime <= 0) {
      state.powerUps.splice(i, 1);
      continue;
    }

    for (const [, player] of state.players) {
      if (!player.alive) continue;
      for (const cell of player.cells) {
        if (distance(cell, pu) < cell.radius + pu.radius) {
          applyPowerUp(cell, pu);
          state.powerUps.splice(i, 1);
          break;
        }
      }
    }
  }
}

function applyPowerUp(cell: Cell, pu: PowerUp): void {
  switch (pu.type) {
    case "mass":
      cell.mass += 50;
      cell.radius = massToRadius(cell.mass);
      break;
    case "speed":
      // Temporarily reduce mass for speed effect
      // (simple approach - actual implementation would use a timer)
      break;
    case "shield":
      // Visual effect only in this simplified version
      break;
  }
}

/** Get leaderboard sorted by score */
export function getLeaderboard(state: GameState): LeaderboardEntry[] {
  const entries: LeaderboardEntry[] = [];
  for (const [, player] of state.players) {
    if (!player.alive) continue;
    entries.push({
      name: player.name,
      score: player.score,
      color: player.color,
    });
  }
  return entries.sort((a, b) => b.score - a.score).slice(0, 10);
}
