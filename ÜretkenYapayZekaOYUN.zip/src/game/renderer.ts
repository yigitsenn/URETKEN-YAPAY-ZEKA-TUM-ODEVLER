/**
 * Canvas renderer for the game.
 * Handles camera, grid, food, cells, power-ups, and HUD.
 */

import type { GameState, Player, Cell, Food, PowerUp, EjectedMass } from "./types";
import { MAP_WIDTH, MAP_HEIGHT, GRID_SIZE, SKINS, CAMERA_LERP, ZOOM_LERP, BASE_ZOOM, MIN_ZOOM } from "./constants";
import { getCenterOfMass, getTotalMass, lerp } from "./utils";

interface Camera {
  x: number;
  y: number;
  zoom: number;
}

let camera: Camera = { x: 0, y: 0, zoom: BASE_ZOOM };

/** Reset camera position */
export function resetCamera(): void {
  camera = { x: 0, y: 0, zoom: BASE_ZOOM };
}

/** Main render function — called every frame */
export function render(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  state: GameState,
  playerId: string
): void {
  const player = state.players.get(playerId);
  if (!player || !player.alive) return;

  // Update camera to follow player
  const center = getCenterOfMass(player.cells);
  const totalMass = getTotalMass(player.cells);

  // Zoom out as player grows
  const targetZoom = Math.max(MIN_ZOOM, BASE_ZOOM - totalMass * 0.0008);
  camera.x = lerp(camera.x, center.x, CAMERA_LERP);
  camera.y = lerp(camera.y, center.y, CAMERA_LERP);
  camera.zoom = lerp(camera.zoom, targetZoom, ZOOM_LERP);

  const w = canvas.width;
  const h = canvas.height;

  // Clear
  ctx.fillStyle = "#111827";
  ctx.fillRect(0, 0, w, h);

  ctx.save();

  // Apply camera transform
  ctx.translate(w / 2, h / 2);
  ctx.scale(camera.zoom, camera.zoom);
  ctx.translate(-camera.x, -camera.y);

  // Draw grid
  drawGrid(ctx);

  // Draw map border
  drawMapBorder(ctx);

  // Draw food
  for (const food of state.food) {
    drawFood(ctx, food);
  }

  // Draw ejected mass
  for (const em of state.ejectedMass) {
    drawEjectedMass(ctx, em);
  }

  // Draw power-ups
  for (const pu of state.powerUps) {
    drawPowerUp(ctx, pu);
  }

  // Draw all player cells (sorted by mass so bigger ones render on top)
  const allCells: { cell: Cell; player: Player }[] = [];
  for (const [, p] of state.players) {
    if (!p.alive) continue;
    for (const cell of p.cells) {
      allCells.push({ cell, player: p });
    }
  }
  allCells.sort((a, b) => a.cell.mass - b.cell.mass);

  for (const { cell, player: p } of allCells) {
    drawCell(ctx, cell, p);
  }

  ctx.restore();
}

function drawGrid(ctx: CanvasRenderingContext2D): void {
  ctx.strokeStyle = "rgba(255,255,255,0.04)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 0; x <= MAP_WIDTH; x += GRID_SIZE) {
    ctx.moveTo(x, 0);
    ctx.lineTo(x, MAP_HEIGHT);
  }
  for (let y = 0; y <= MAP_HEIGHT; y += GRID_SIZE) {
    ctx.moveTo(0, y);
    ctx.lineTo(MAP_WIDTH, y);
  }
  ctx.stroke();
}

function drawMapBorder(ctx: CanvasRenderingContext2D): void {
  ctx.strokeStyle = "rgba(255,100,100,0.3)";
  ctx.lineWidth = 4;
  ctx.strokeRect(0, 0, MAP_WIDTH, MAP_HEIGHT);
}

function drawFood(ctx: CanvasRenderingContext2D, food: Food): void {
  ctx.fillStyle = food.color;
  ctx.globalAlpha = 0.8;
  ctx.beginPath();
  ctx.arc(food.x, food.y, food.radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawEjectedMass(ctx: CanvasRenderingContext2D, em: EjectedMass): void {
  ctx.fillStyle = em.color;
  ctx.globalAlpha = 0.6;
  ctx.beginPath();
  ctx.arc(em.x, em.y, em.radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

function drawPowerUp(ctx: CanvasRenderingContext2D, pu: PowerUp): void {
  const pulse = 1 + Math.sin(Date.now() * 0.005) * 0.15;
  const r = pu.radius * pulse;

  // Glow
  const grad = ctx.createRadialGradient(pu.x, pu.y, 0, pu.x, pu.y, r * 2);
  const colors: Record<string, string> = {
    speed: "#FFD93D",
    shield: "#4ECDC4",
    mass: "#FF6B6B",
  };
  const color = colors[pu.type] || "#fff";
  grad.addColorStop(0, color);
  grad.addColorStop(1, "transparent");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(pu.x, pu.y, r * 2, 0, Math.PI * 2);
  ctx.fill();

  // Core
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(pu.x, pu.y, r, 0, Math.PI * 2);
  ctx.fill();

  // Icon
  ctx.fillStyle = "#111";
  ctx.font = `bold ${r}px sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const icons: Record<string, string> = { speed: "⚡", shield: "🛡", mass: "+" };
  ctx.fillText(icons[pu.type] || "?", pu.x, pu.y);
}

function drawCell(ctx: CanvasRenderingContext2D, cell: Cell, player: Player): void {
  const { x, y, radius, color } = cell;

  // Shadow / glow
  ctx.shadowColor = color;
  ctx.shadowBlur = 15;

  // Cell body with gradient
  const grad = ctx.createRadialGradient(x - radius * 0.3, y - radius * 0.3, 0, x, y, radius);
  grad.addColorStop(0, lightenColor(color, 30));
  grad.addColorStop(1, color);
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();

  // Skin overlay
  if (player.skin && player.skin > 0) {
    drawSkin(ctx, x, y, radius, player.skin);
  }

  // Outline
  ctx.shadowBlur = 0;
  ctx.strokeStyle = darkenColor(color, 30);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.stroke();

  // Player name
  if (radius > 15) {
    const fontSize = Math.max(10, Math.min(radius * 0.45, 24));
    ctx.font = `bold ${fontSize}px 'Segoe UI', sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // Text shadow
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillText(player.name, x + 1, y + 1);

    ctx.fillStyle = "#fff";
    ctx.fillText(player.name, x, y);

    // Mass number
    if (radius > 30) {
      const massFontSize = fontSize * 0.65;
      ctx.font = `${massFontSize}px 'Segoe UI', sans-serif`;
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.fillText(Math.floor(cell.mass).toString(), x, y + fontSize * 0.7);
    }
  }
}

function drawSkin(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, skinIdx: number): void {
  ctx.save();
  ctx.globalAlpha = 0.2;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.clip();

  switch (SKINS[skinIdx]) {
    case "stripes":
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 3;
      for (let i = -radius; i < radius; i += 10) {
        ctx.beginPath();
        ctx.moveTo(x + i, y - radius);
        ctx.lineTo(x + i, y + radius);
        ctx.stroke();
      }
      break;
    case "dots":
      ctx.fillStyle = "#fff";
      for (let dx = -radius; dx < radius; dx += 15) {
        for (let dy = -radius; dy < radius; dy += 15) {
          ctx.beginPath();
          ctx.arc(x + dx, y + dy, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    case "star":
      ctx.fillStyle = "#fff";
      ctx.font = `${radius}px sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("★", x, y);
      break;
    case "gradient":
      const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
      g.addColorStop(0, "rgba(255,255,255,0.4)");
      g.addColorStop(1, "rgba(0,0,0,0.2)");
      ctx.fillStyle = g;
      ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
      break;
  }

  ctx.restore();
}

/** Get camera info for converting screen coords to world coords */
export function getCamera(): Camera {
  return { ...camera };
}

/** Convert screen position to world position */
export function screenToWorld(
  screenX: number, screenY: number,
  canvasW: number, canvasH: number
): { x: number; y: number } {
  return {
    x: camera.x + (screenX - canvasW / 2) / camera.zoom,
    y: camera.y + (screenY - canvasH / 2) / camera.zoom,
  };
}

// Color utility functions
function lightenColor(hex: string, amount: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgb(${Math.min(255, r + amount)},${Math.min(255, g + amount)},${Math.min(255, b + amount)})`;
}

function darkenColor(hex: string, amount: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgb(${Math.max(0, r - amount)},${Math.max(0, g - amount)},${Math.max(0, b - amount)})`;
}
