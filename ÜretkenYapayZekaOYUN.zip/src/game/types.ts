/**
 * Core type definitions for the CellStorm game.
 */

export interface Vector2 {
  x: number;
  y: number;
}

/** A food particle on the map */
export interface Food {
  id: number;
  x: number;
  y: number;
  radius: number;
  color: string;
}

/** A cell belonging to a player (supports splitting into multiple cells) */
export interface Cell {
  id: number;
  x: number;
  y: number;
  radius: number;
  mass: number;
  vx: number;
  vy: number;
  color: string;
  mergeTimer: number; // countdown before cells can re-merge
}

/** An ejected mass blob */
export interface EjectedMass {
  id: number;
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  color: string;
  lifetime: number;
}

/** A player (human or bot) */
export interface Player {
  id: string;
  name: string;
  cells: Cell[];
  color: string;
  isBot: boolean;
  score: number;
  alive: boolean;
  skin?: number; // index into SKINS array
}

/** Power-up types */
export type PowerUpType = "speed" | "shield" | "mass";

export interface PowerUp {
  id: number;
  x: number;
  y: number;
  type: PowerUpType;
  radius: number;
  lifetime: number;
}

/** Leaderboard entry */
export interface LeaderboardEntry {
  name: string;
  score: number;
  color: string;
}

/** Game state */
export interface GameState {
  players: Map<string, Player>;
  food: Food[];
  ejectedMass: EjectedMass[];
  powerUps: PowerUp[];
}
