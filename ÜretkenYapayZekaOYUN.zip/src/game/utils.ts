/**
 * Utility functions for the game engine.
 */
import type { Vector2, Cell } from "./types";

/** Distance between two points */
export function distance(a: Vector2, b: Vector2): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/** Convert mass to radius */
export function massToRadius(mass: number): number {
  return Math.sqrt(mass) * 4;
}

/** Clamp value between min and max */
export function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

/** Linear interpolation */
export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/** Get total mass of all cells */
export function getTotalMass(cells: Cell[]): number {
  return cells.reduce((sum, c) => sum + c.mass, 0);
}

/** Get center position of all cells (weighted by mass) */
export function getCenterOfMass(cells: Cell[]): Vector2 {
  if (cells.length === 0) return { x: 0, y: 0 };
  let totalMass = 0;
  let cx = 0;
  let cy = 0;
  for (const cell of cells) {
    cx += cell.x * cell.mass;
    cy += cell.y * cell.mass;
    totalMass += cell.mass;
  }
  return { x: cx / totalMass, y: cy / totalMass };
}

/** Generate a random position within the map */
export function randomPosition(mapW: number, mapH: number, margin = 100): Vector2 {
  return {
    x: margin + Math.random() * (mapW - margin * 2),
    y: margin + Math.random() * (mapH - margin * 2),
  };
}

/** Pick a random element from an array */
export function randomPick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** Normalize a vector */
export function normalize(v: Vector2): Vector2 {
  const len = Math.sqrt(v.x * v.x + v.y * v.y);
  if (len === 0) return { x: 0, y: 0 };
  return { x: v.x / len, y: v.y / len };
}
