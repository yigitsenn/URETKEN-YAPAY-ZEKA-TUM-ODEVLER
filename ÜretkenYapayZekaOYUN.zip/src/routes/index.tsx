import { createFileRoute } from "@tanstack/react-router";
import GameCanvas from "../components/GameCanvas";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "CellStorm — Agar.io Style Game" },
      { name: "description", content: "Consume, grow, dominate. A multiplayer-style cell game with AI bots." },
    ],
  }),
});

function Index() {
  return <GameCanvas />;
}
